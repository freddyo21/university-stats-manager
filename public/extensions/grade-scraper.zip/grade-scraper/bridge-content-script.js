// File này CHỈ chạy trên domain web app của bạn (khai báo matches ở manifest)
chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "SYNC_DATA_FROM_EXTENSION") {
        // Forward vào window để React (hoặc bất kỳ frontend nào) nhận được
        window.postMessage(
            { source: "EXTENSION_BRIDGE", action: "SYNC_DATA", data: message.data },
            window.location.origin // chỉ định rõ origin, an toàn hơn "*"
        );
    }
});