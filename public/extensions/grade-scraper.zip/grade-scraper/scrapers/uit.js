export function uitScrapingStrategy() {
    const table = document.querySelector("table:last-of-type");
    if (!table) return { error: "Không tìm thấy bảng điểm UIT" };

    const rows = Array.from(table.querySelectorAll("tr"));
    let countSemesterRows = rows.filter(row => row.querySelector("td[colspan=\"10\"]")).length;
    const countSemesterRowsSnapshot = countSemesterRows;

    if (countSemesterRows > 0) {
        rows.forEach((row) => {
            if (row.rowIndex === 0) return;

            const hasColspan10 = row.querySelector("td[colspan=\"10\"]");
            if (hasColspan10) {
                row.setAttribute("data-is-semester-row", "true");
                row.setAttribute("data-semester-id", String(countSemesterRows));
                return;
            }

            const isAverageSemester = row.querySelector("td strong");
            if (isAverageSemester && isAverageSemester.innerText.includes("Trung bình học kỳ")) {
                row.setAttribute("data-is-average-semester-row", "true");
                countSemesterRows--;
                return;
            }

            row.setAttribute("data-is-course-row", "true");
            row.setAttribute("data-semester-id", String(countSemesterRows));
        });
    }

    const weightConverter = (weightStr) => {
        if (!weightStr) return 0;
        const weight = weightStr.includes("Trọng số: ")
            ? weightStr.replace("Trọng số: ", "").replace("%", "")
            : Number(weightStr * 100);
        return Number(weight) || 0;
    };

    const data = [];
    for (let i = 0; i < countSemesterRowsSnapshot; ++i) {
        data.push({ semester: i + 1, subjects: [] });
    }

    for (let i = 0; i < rows.length; ++i) {
        const row = rows[i];
        if (!row.hasAttribute("data-is-course-row") && !row.hasAttribute("data-semester-id")) continue;

        const currentSemesterIndex = Number(row.getAttribute("data-semester-id"));
        if (row.hasAttribute("data-is-semester-row")) continue;

        const semester = data.find((s) => s.semester === currentSemesterIndex);
        if (semester) {
            semester.subjects.push({
                code: row.cells[1]?.innerText.trim(),
                name: row.cells[2]?.innerText.trim(),
                credits: Number(row.cells[3]?.innerText?.trim()) || 0,
                weights: {
                    process: weightConverter(row.cells[4]?.title?.trim()),
                    midterm: weightConverter(row.cells[5]?.title?.trim()),
                    practice: weightConverter(row.cells[6]?.title?.trim()),
                    final: weightConverter(row.cells[7]?.title?.trim()),
                },
                scores: {
                    process: Number(row.cells[4]?.innerText?.trim()) || 0,
                    midterm: Number(row.cells[5]?.innerText?.trim()) || 0,
                    practice: Number(row.cells[6]?.innerText?.trim()) || 0,
                    final: Number(row.cells[7]?.innerText?.trim()) || 0,
                },
                isExempt: row.cells[8]?.innerText?.trim() === "Miễn",
            });
        }
    }

    return { school: "uit", data };
}