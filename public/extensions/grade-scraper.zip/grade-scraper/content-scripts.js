(() => {
    // 1. Tạo nút bấm đồng bộ
    const syncButton = document.createElement("button");
    syncButton.innerText = "✨ Đồng bộ với Trợ lý AI";
    syncButton.style.position = "fixed";
    syncButton.style.bottom = "20px";
    syncButton.style.right = "20px";
    syncButton.style.zIndex = "9999";
    syncButton.style.padding = "12px 24px";
    syncButton.style.backgroundColor = "#0070f3";
    syncButton.style.color = "#ffffff";
    syncButton.style.border = "none";
    syncButton.style.borderRadius = "8px";
    syncButton.style.cursor = "pointer";
    syncButton.style.boxShadow = "0 4px 14px rgba(0,0,0,0.16)";

    document.body.appendChild(syncButton);

    // 2. Click Event
    syncButton.addEventListener("click", () => {
        syncButton.innerText = "⏳ Đang xử lý dữ liệu...";
        syncButton.disabled = true;

        // Kiểm tra context còn sống không TRƯỚC khi gọi sendMessage
        if (typeof chrome === "undefined" || !chrome.runtime?.id) {
            syncButton.innerText = "🔄 Vui lòng tải lại trang";
            syncButton.disabled = false;
            console.error("Extension context bị invalidated (do reload/update extension). Cần reload tab.");
            return;
        }

        try {
            chrome.runtime.sendMessage(
                {
                    action: "FETCH_AND_RUN_STRATEGY",
                    domain: window.location.origin,
                },
                () => {
                    // Bắt lỗi runtime.lastError để tránh "Unchecked runtime.lastError" trong console
                    if (chrome.runtime.lastError) {
                        console.error("Lỗi khi gửi message:", chrome.runtime.lastError.message);
                        syncButton.innerText = "🔄 Vui lòng tải lại trang";
                        syncButton.disabled = false;
                    }
                }
            );
        } catch (err) {
            // Context invalidated throw đồng bộ ngay tại đây, không qua callback
            console.error("Extension context invalidated:", err);
            syncButton.innerText = "🔄 Vui lòng tải lại trang";
            syncButton.disabled = false;
        }
    });

    // 3. Lắng nghe phản hồi từ Background trả về để cập nhật trạng thái UI
    chrome.runtime.onMessage.addListener((message) => {
        if (message.action === "STRATEGY_SUCCESS") {
            syncButton.innerText = "✅ Đồng bộ thành công!";
            syncButton.style.backgroundColor = "#0070f3";
            setTimeout(() => {
                syncButton.innerText = "✨ Đồng bộ với Trợ lý AI";
                syncButton.disabled = false;
            }, 3000);
        }

        if (message.action === "STRATEGY_FAILED") {
            syncButton.innerText = "❌ Thất bại. Thử lại";
            syncButton.style.backgroundColor = "#ea0000";
            syncButton.disabled = false;
            console.error("Lỗi thực thi chiến lược:", message.error);
        }
    });
})();