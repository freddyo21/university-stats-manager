import { uitScrapingStrategy } from "./scrapers/uit.js";

export const SCRAPERS = {
    uit: uitScrapingStrategy,
};