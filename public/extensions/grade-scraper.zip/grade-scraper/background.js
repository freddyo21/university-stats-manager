﻿import { SCRAPERS } from "./scrapers.js";

const APP_URLS = [
    "http://localhost:3000/*",
    "http://localhost:5173/*",
    "https://study-stats-suite.vercel.app/*"
];

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.action !== "RUN_SCRAPER") {
        return;
    }

    // Permission has already been granted by popup.js before this message is sent.
    // This handler only does scripting — no chrome.permissions.request() needed here.
    (async () => {
        const { tabId, domain } = message;

        if (!tabId) {
            sendResponse({ success: false, error: "Thiếu tabId." });
            return;
        }

        try {
            // ── 1. Resolve school key from server ─────────────────
            const response = await fetch(
                `http://localhost:3000/api/get-script?domain=${encodeURIComponent(domain)}`
            );

            if (!response.ok) {
                throw new Error(`Server trả về HTTP ${response.status}`);
            }

            const resData = await response.json();

            if (resData.error) {
                throw new Error(resData.error);
            }

            const schoolKey = resData.schoolKey;
            const scraperFn = SCRAPERS[schoolKey];

            if (!scraperFn) {
                throw new Error(`Không có scraper cho key "${schoolKey}"`);
            }

            // ── 2. Execute scraper in the university tab ───────────
            const results = await chrome.scripting.executeScript({
                target: { tabId },
                func: scraperFn
            });

            const finalData = results?.[0]?.result;

            if (!finalData) {
                throw new Error("Scraper không trả về dữ liệu.");
            }

            // ── 3. Forward data to web app tabs ───────────────────
            const appTabs = await chrome.tabs.query({ url: APP_URLS });

            if (!appTabs.length) {
                console.warn("Không tìm thấy tab web app nào đang mở.");
            }

            for (const tab of appTabs) {
                chrome.tabs.sendMessage(tab.id, {
                    action: "SYNC_DATA_FROM_EXTENSION",
                    data: finalData
                }).catch(() => {
                    // Tab may not have bridge content script yet — safe to ignore
                });
            }

            sendResponse({ success: true });
        } catch (err) {
            console.error("Lỗi hệ thống:", err);
            sendResponse({ success: false, error: err.message });
        }
    })();

    return true; // keep message channel open for async sendResponse
});
