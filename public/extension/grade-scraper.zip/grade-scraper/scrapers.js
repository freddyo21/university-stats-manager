import { uitNewScrapingStrategy } from "./scrapers/uit-new.js";
// import { uitScrapingStrategy } from "./scrapers/uit.js";

export const SCRAPERS = {
    uit: uitNewScrapingStrategy,
    // uitNew: uitNewScrapingStrategy,
};