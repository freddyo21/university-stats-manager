﻿// popup.js — runs in popup.html context (has Trusted User Activation on icon click)

const statusEl   = document.getElementById("status");
const domainEl   = document.getElementById("domain-info");
const syncBtn    = document.getElementById("btn-sync");

// ─────────────────────────────────────────────────────────────
// On popup open: inspect the active tab
// ─────────────────────────────────────────────────────────────
async function init() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab?.url) {
        statusEl.textContent = "Không thể đọc URL của trang hiện tại.";
        return;
    }

    let origin;
    try {
        origin = new URL(tab.url).origin;
    } catch {
        statusEl.textContent = "URL không hợp lệ.";
        return;
    }

    // Check if this origin is covered by optional_host_permissions
    const isOptional = await chrome.permissions.contains({
        origins: [`${origin}/*`]
    });

    // Show domain
    domainEl.textContent = origin;
    domainEl.style.display = "block";

    if (isOptional) {
        statusEl.textContent = "Quyền đã được cấp. Sẵn sàng đồng bộ.";
    } else {
        statusEl.textContent = "Cần cấp quyền để truy cập trang này.";
    }

    syncBtn.disabled = false;
    syncBtn.dataset.tabId     = tab.id;
    syncBtn.dataset.origin    = origin;
    syncBtn.dataset.hasPermission = isOptional ? "1" : "0";
}

// ─────────────────────────────────────────────────────────────
// Button click: request permission (if needed) then run scraper
// This is called directly in popup context → TUA is valid here.
// ─────────────────────────────────────────────────────────────
syncBtn.addEventListener("click", async () => {
    syncBtn.disabled  = true;
    syncBtn.className = "";
    statusEl.textContent = "⏳ Đang xử lý...";

    const tabId  = Number(syncBtn.dataset.tabId);
    const origin = syncBtn.dataset.origin;
    const originPattern = `${origin}/*`;

    // ── 1. Request permission if not already granted ──────────
    // chrome.permissions.request() MUST be called in popup context.
    // Calling it here is correct: the user just clicked the extension icon (TUA).
    let alreadyGranted = syncBtn.dataset.hasPermission === "1";

    if (!alreadyGranted) {
        let granted = false;
        try {
            granted = await chrome.permissions.request({
                origins: [originPattern]
            });
        } catch (err) {
            // This should not throw here, but guard anyway
            setError(`Không thể yêu cầu quyền: ${err.message}`);
            return;
        }

        if (!granted) {
            setError("Người dùng từ chối cấp quyền.");
            return;
        }
    }

    // ── 2. Delegate actual scraping to service worker ─────────
    // Permission is now granted; SW can call scripting.executeScript freely.
    chrome.runtime.sendMessage(
        { action: "RUN_SCRAPER", tabId, domain: origin },
        (response) => {
            if (chrome.runtime.lastError) {
                setError(chrome.runtime.lastError.message);
                return;
            }
            if (response?.success) {
                setSuccess("✅ Đồng bộ thành công!");
            } else {
                setError(response?.error ?? "Lỗi không xác định.");
            }
        }
    );
});

function setSuccess(msg) {
    statusEl.textContent  = msg;
    syncBtn.className     = "success";
    syncBtn.disabled      = false;
    syncBtn.textContent   = "Đồng bộ lại";
}

function setError(msg) {
    statusEl.textContent  = msg;
    syncBtn.className     = "error";
    syncBtn.disabled      = false;
    syncBtn.textContent   = "Thử lại";
}

init();
