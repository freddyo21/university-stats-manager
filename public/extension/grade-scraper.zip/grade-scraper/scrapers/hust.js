export function hustScrapingStrategy() {
    let data = [];

    return { school: "hust", data };
}