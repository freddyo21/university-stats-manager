export function uitNewScrapingStrategy() {
    const semesterPanel = document.querySelector("[id^='radix-'][id$='-content-by-semester']");
    if (!semesterPanel) {
        return {
            success: false,
            error: "Không tìm thấy bảng điểm học kỳ UIT"
        };
    }

    const isActive = semesterPanel.getAttribute("data-state") === "active";
    if (!isActive) {
        return {
            success: false,
            error: "Bạn phải mở tab `Chi tiết môn học` để tiến hành quét"
        };
    }

    // 1. Bước một: Cào thô toàn bộ các học kỳ và môn học không phân biệt thứ tự DOM
    const rawSemesters = [];
    const semesterCards = semesterPanel.querySelectorAll(".rounded-lg.border.border-border.bg-card");

    semesterCards.forEach((card) => {
        const headerEl = card.querySelector("h3");
        if (!headerEl) return;

        // 🚀 TRÍCH XUẤT MÃ HỌC KỲ CHUẨN ĐÀO TẠO (Ví dụ: Học kỳ 2/2025-2026 -> 20252)
        // Nhóm 1 (kỳ): bốc số học kỳ nằm sau chữ "Học kỳ "
        // Nhóm 2 (năm): bốc 4 số năm học bắt đầu nằm sau dấu "/"
        const semesterName = headerEl.textContent.trim();

        // 2. Định nghĩa Regex để bắt số học kỳ và năm học
        // Pattern giải thích:
        // - Học kỳ (\d+) : Bắt group 1 là số học kỳ (1 hoặc nhiều chữ số)
        // - Năm học (\d{4}): Bắt group 2 là 4 chữ số của năm bắt đầu
        const regex = /Học kỳ\s+(\d+)\/(\d{4})/i;
        const match = semesterName.match(regex);

        let semesterId = "";
        if (match) {
            const semesterNum = match[1]; // "3"
            const startYear = match[2];   // "2024"

            // 3. Ghép lại thành mã semesterId theo chuẩn hệ thống: <năm><kỳ>
            semesterId = `${startYear}${semesterNum}`;
        } else {
            const fallbackDigits = semesterName.match(/\d+/g);
            semesterId = fallbackDigits ? fallbackDigits.join("") : "";
        }

        // B. Tìm bảng điểm bên trong card
        const table = card.querySelector("table");
        if (!table) return;

        const rows = table.querySelectorAll("tbody tr");
        const subjects = [];

        let studyType = "normal";

        // C. Duyệt từng dòng môn học (tr) trong bảng
        rows.forEach((row) => {
            const cells = row.querySelectorAll("td");
            if (cells.length < 8) return;

            const parseWeight = (cell) => {
                if (!cell) return 0;
                const title = cell.getAttribute("title") || "";
                const matchWeight = title.match(/(\d+)%/);
                return matchWeight ? parseInt(matchWeight[1], 10) : 0;
            };

            const parseScore = (cell) => {
                if (!cell) return null;
                const txt = cell.textContent.trim();
                if (txt === "—" || txt === "") return null;
                const scoreFloat = parseFloat(txt.replace(",", "."));
                return isNaN(scoreFloat) ? null : scoreFloat;
            };

            const code = cells[0].textContent.trim().toUpperCase().replace(/\s+/g, ""); // Xóa sạch khoảng trắng ẩn
            const name = cells[1].querySelector("span")?.textContent.trim() || cells[1].textContent.trim();
            const credits = parseInt(cells[2].textContent.trim(), 10) || 0;

            const processScore = parseScore(cells[3]);
            const processWeight = parseWeight(cells[3]);

            const practiceScore = parseScore(cells[4]);
            const practiceWeight = parseWeight(cells[4]);

            const midtermScore = parseScore(cells[5]);
            const midtermWeight = parseWeight(cells[5]);

            const finalScore = parseScore(cells[6]);
            const finalWeight = parseWeight(cells[6]);

            const gpa10 = parseScore(cells[7]);

            subjects.push({
                code: code,
                name: name,
                credits: credits,
                weights: {
                    process: processWeight,
                    midterm: midtermWeight,
                    practice: practiceWeight,
                    final: finalWeight
                },
                scores: {
                    process: processScore,
                    midterm: midtermScore,
                    practice: practiceScore,
                    final: finalScore
                },
                studyType,
                gpa10
            });
        });

        rawSemesters.push({
            semesterId,
            subjects
        });
    });

    // 2. Bước hai: Sắp xếp các học kỳ tăng dần theo dòng thời gian thực tế (ví dụ: 20241 < 20242 < 20251)
    rawSemesters.sort((a, b) => Number(a.semesterId) - Number(b.semesterId));

    // 3. Bước ba: Quét tuyến tính theo trục thời gian chuẩn để gắn nhãn studyType chuẩn xác
    const globalSubjectsHistoryMap = new Map();
    const finalScrapedSemesters = [];

    rawSemesters.forEach((semBlock, idx) => {
        const processedSubjects = semBlock.subjects.map((sub) => {
            let currentStudyType = sub.studyType; // Mặc định lấy nhãn studyType từ DOM, nhưng sẽ ghi đè nếu phát hiện học lại/cải thiện

            // Nếu môn này đã từng xuất hiện ở các học kỳ trước đó trong quá khứ
            if (globalSubjectsHistoryMap.has(sub.code)) {
                const pastGPA10 = globalSubjectsHistoryMap.get(sub.code);
                if (pastGPA10 !== null && pastGPA10 < 5.0) {
                    currentStudyType = "retake";       // Học lại do kỳ trước tạch
                } else {
                    currentStudyType = "improvement";  // Học cải thiện do kỳ trước >= 5.0 nhưng muốn nâng điểm
                }
            }

            // Cập nhật hoặc ghi đè điểm số mới nhất của học kỳ này vào Map lịch sử để tính cho kỳ sau nữa
            globalSubjectsHistoryMap.set(sub.code, sub.gpa10);

            return {
                code: sub.code,
                name: sub.name,
                credits: sub.credits,
                weights: sub.weights,
                scores: sub.scores,
                studyType: currentStudyType, // Nhãn chuẩn đập tan lỗi môn học mới
                gpa10: sub.gpa10
            };
        });

        finalScrapedSemesters.push({
            semesterId: semBlock.semesterId,
            semester: idx + 1, // Số thứ tự tăng dần chuẩn chỉnh
            subjects: processedSubjects
        });
    });

    // 4. Trả kết quả về cho Extension. Lưu ý trả ngược lại trật tự hiển thị nếu muốn giao diện Web App nuốt thuận chiều
    return { success: true, school: "uit", data: finalScrapedSemesters };
}