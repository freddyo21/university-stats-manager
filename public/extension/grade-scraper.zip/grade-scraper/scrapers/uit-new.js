export function uitNewScrapingStrategy() {
    // 🔍 1. Định vị vùng chứa học kỳ dựa trên ID động của Radix
    const semesterPanel = document.querySelector("[id^='radix-'][id$='-content-by-semester']");
    if (!semesterPanel) {
        return {
            success: false,
            error: "Không tìm thấy bảng điểm học kỳ UIT"
        };
    }

    const isActive = semesterPanel.getAttribute("data-state") === "active";
    if (!isActive) {
        return {
            success: false,
            error: "Bạn phải mở tab `Chi tiết môn học` để tiến hành quét"
        };
        // throw new Error("Bạn phải mở tab `Chi tiết môn học` để tiến hành quét");
    }

    // 📦 Mảng chứa kết quả các học kỳ cào được
    const scrapedSemesters = [];

    // 🔍 2. Quét tất cả các card học kỳ con bên trong Panel
    // Dựa trên cấu trúc: Mỗi học kỳ nằm trong một div có border, chứa header và table
    const semesterCards = semesterPanel.querySelectorAll(".rounded-lg.border.border-border.bg-card");
    const semestersCount = semesterCards.length;

    semesterCards.forEach((card, index) => {
        // A. Bóc tách Header của Học kỳ (Tên học kỳ, Mã học kỳ trường)
        const headerEl = card.querySelector("h3");
        if (!headerEl) return;

        const semesterName = headerEl.textContent.trim(); // Ví dụ: "Học kỳ 2/2025-2026"
        // const matchFormat = semesterName.match(/Học kỳ\s+(\d+)\/(\d{4})/i);

        let semesterId = "";
        // let semesterNumber = scrapedSemesters.length + 1;

        // if (matchFormat) {
        //     const extSemesterNum = matchFormat[1]; // "2"
        //     const startYear = matchFormat[2];      // "2025"

        //     semesterId = `${startYear}${extSemesterNum}`; // Ép chuỗi cấu trúc ghép: "20252"
        //     semesterNumber = parseInt(extSemesterNum, 10); // Lấy số kỳ thô: 2
        // } else {
        //     // Phòng thủ nếu là học kỳ đặc biệt không đúng format chuẩn của trường
        //     const fallbackDigits = semesterName.match(/\d+/g);
        //     semesterId = fallbackDigits ? fallbackDigits.join("") : "";
        // }

        // 🚀 TRÍCH XUẤT MÃ HỌC KỲ CHUẨN ĐÀO TẠO (Ví dụ: Học kỳ 2/2025-2026 -> 20252)
        // Nhóm 1 (kỳ): bốc số học kỳ nằm sau chữ "Học kỳ "
        // Nhóm 2 (năm): bốc 4 số năm học bắt đầu nằm sau dấu "/"
        const getSemesterName = () => {
            const targetText = semesterName;

            // 2. Định nghĩa Regex để bắt số học kỳ và năm học
            // Pattern giải thích:
            // - Học kỳ (\d+) : Bắt group 1 là số học kỳ (1 hoặc nhiều chữ số)
            // - Năm học (\d{4}): Bắt group 2 là 4 chữ số của năm bắt đầu
            const regex = /Học kỳ\s+(\d+)\/(\d{4})/i;
            const match = targetText.match(regex);

            if (match) {
                const semesterNum = match[1]; // "3"
                const startYear = match[2];    // "2024"

                // 3. Ghép lại thành mã semesterId theo chuẩn hệ thống: <năm><kỳ>
                const semesterId = `${startYear}${semesterNum}`; // "20243"

                // console.log("Học kỳ:", semesterNum);
                // console.log("Năm bắt đầu:", startYear);
                // console.log("Mã học kỳ (semesterId):", semesterId);
                return semesterId;
            } else {
                console.log("Chuỗi văn bản không khớp với định dạng chuẩn.");
            }
        }

        // B. Tìm bảng điểm bên trong card
        const table = card.querySelector("table");
        if (!table) return;

        const rows = table.querySelectorAll("tbody tr");
        const subjects = [];

        // C. Duyệt từng dòng môn học (tr) trong bảng
        rows.forEach((row) => {
            const cells = row.querySelectorAll("td");
            if (cells.length < 8) return; // Phòng thủ dòng rác hoặc dòng tổng kết

            // 🚀 BÓC TÁCH KIỂU DUYỆT LỚP MÀU (STUDY TYPE) DỰA TRÊN CLASS NAME CỦA TR
            const rowClass = row.className || "";
            let studyType = "normal";

            // if (rowClass.includes("bg-rose-500") || rowClass.includes("text-rose-500")) {
            //     studyType = "retake";    // Trả nợ
            // } else if (rowClass.includes("bg-purple-500") || rowClass.includes("text-purple-500")) {
            //     studyType = "exempt";    // Miễn
            // }
            // else if (rowClass.includes("bg-orange-500") || rowClass.includes("text-orange-500")) {
            //     studyType = "postpone";  // Hoãn thi
            // } 
            // else if (rowClass.includes("bg-blue-500") || rowClass.includes("text-blue-500")) {
            //     studyType = "improvement";   // Cải thiện
            // }
            // else if (rowClass.includes("bg-amber-500") || rowClass.includes("text-amber-500")) {
            //     studyType = "reserve";   // Bảo lưu
            // }

            // D. Trích xuất trọng số từ thuộc tính "title" của các ô điểm
            const parseWeight = (cell) => {
                if (!cell) return null;
                const title = cell.getAttribute("title") || "";
                const match = title.match(/(\d+)%/);
                return match ? parseInt(match[1], 10) : null;
            };

            const parseScore = (cell) => {
                if (!cell) return null;
                const txt = cell.textContent.trim();
                if (txt === "—" || txt === "") return null;
                // Đổi dấu phẩy hệ Việt Nam thành dấu chấm hệ Quốc tế trước khi ép kiểu float
                const scoreFloat = parseFloat(txt.replace(",", "."));
                return isNaN(scoreFloat) ? null : scoreFloat;
            };

            // E. Định vị chính xác các ô dựa trên cấu trúc table-fixed
            const code = cells[0].textContent.trim();
            const name = cells[1].querySelector("span")?.textContent.trim() || cells[1].textContent.trim();
            const credits = parseInt(cells[2].textContent.trim(), 10) || 0;

            const processScore = parseScore(cells[3]);
            const processWeight = parseWeight(cells[3]);

            const practiceScore = parseScore(cells[4]);
            const practiceWeight = parseWeight(cells[4]);

            const midtermScore = parseScore(cells[5]);
            const midtermWeight = parseWeight(cells[5]);

            const finalScore = parseScore(cells[6]);
            const finalWeight = parseWeight(cells[6]);

            const gpa10 = parseScore(cells[7]);

            // F. Đóng gói môn học đúng chuẩn Interface để Web App v2 nuốt mượt mà
            subjects.push({
                code: code,
                name: name,
                credits: credits,
                weights: {
                    process: processWeight,
                    midterm: midtermWeight,
                    practice: practiceWeight,
                    final: finalWeight
                },
                scores: {
                    process: processScore,
                    midterm: midtermScore,
                    practice: practiceScore,
                    final: finalScore
                },
                studyType: studyType,
                gpa10: gpa10
            });
        });

        // G. Tìm số thứ tự học kỳ thuần túy (ví dụ: Học kỳ 2 -> bốc số 2)
        // const semesterNumMatch = semesterName.match(/Học kỳ\s+(\d+)/i);
        // if (semesterNumMatch) {
        //     semesterNumber = parseInt(semesterNumMatch[1], 10);
        // } else {
        // semesterNumber = scrapedSemesters.length + 1;
        // }

        // Đóng gói cấu trúc Học kỳ hoàn chỉnh
        scrapedSemesters.push({
            semesterId: getSemesterName(),
            semester: semestersCount - index,
            subjects: subjects
        });
    });



    // document.querySelector("[id^='radix-'][id$='-trigger-by-ctdt']").click();

    return { success: true, school: "uit", data: scrapedSemesters };
}